# # # app.py
# # import streamlit as st
# # from tools import agent_router

# # st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# # st.title("📚 Multi-Agent RAG Q&A")
# # query = st.text_input("Ask me anything...")

# # if query:
# #     with st.spinner("Thinking..."):
# #         response = agent_router(query)
# #         st.success("✅ Answer generated!")

# #         st.markdown(f"🔁 Agent Path Chosen:** {response['route']}")

# #         if 'context' in response:
# #             st.markdown("**📄 Top Retrieved Chunks:**")
# #             for i, chunk in enumerate(response['context']):
# #                 st.markdown(f"**Chunk {i+1}:** {chunk}")

# #         st.markdown(f"**💬 Final Answer:** {response['result']}")
# import streamlit as st
# from tools import agent_router

# # Set up the Streamlit page configuration
# st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# # Title of the app
# st.title("📚 Multi-Agent RAG Q&A")

# # Text input field for the user to ask a query
# query = st.text_input("Ask me anything...")

# # Function to handle the response and display UI elements
# if query:
#     with st.spinner("Thinking..."):
#         try:
#             # Get the response from the agent_router function
#             response = agent_router(query)
            
#             # Display success message after processing the query
#             st.success("✅ Answer generated!")
            
#             # Display the agent path (route) chosen for the query
#             st.markdown(f"🔁 Agent Path Chosen: **{response['route']}**")
            
#             # Display context if available
#             if 'context' in response:
#                 st.markdown("**📄 Top Retrieved Chunks:**")
#                 for i, chunk in enumerate(response['context']):
#                     st.markdown(f"**Chunk {i+1}:** {chunk}")
            
#             # Display the final answer
#             st.markdown(f"**💬 Final Answer:** {response['result']}")

#         except Exception as e:
#             # In case of any error, display an error message
#             st.error(f"⚠️ Error occurred: {e}")

# # Debug Mode (Optional)
# if st.checkbox('Show Debug Log', False):
#     with open('agent.log', 'r') as log_file:
#         st.text_area("Debug Log", log_file.read(), height=300)
# app.py

# import streamlit as st
# from tools import agent_router

# # Page config
# st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# # Title
# st.title("📚 Multi-Agent RAG Q&A")

# # Layout with search bar and file uploader
# col1, col2 = st.columns([5, 1])

# with col1:
#     query = st.text_input("Ask me anything...")

# with col2:
#     uploaded_files = st.file_uploader("📂", type=["pdf", "docx", "txt"], accept_multiple_files=True, label_visibility="collapsed")

# # Show uploaded files (optional display for debug or future ingestion)
# if uploaded_files:
#     st.markdown("### 📥 Uploaded Documents:")
#     for file in uploaded_files:
#         st.markdown(f"- {file.name}")

# # Process query if provided
# if query:
#     with st.spinner("Thinking..."):
#         try:
#             response = agent_router(query)

#             st.success("✅ Answer generated!")
#             st.markdown(f"🔁 Agent Path Chosen: **{response['route']}**")

#             if 'context' in response:
#                 st.markdown("**📄 Top Retrieved Chunks:**")
#                 for i, chunk in enumerate(response['context']):
#                     st.markdown(f"**Chunk {i+1}:** {chunk}")

#             st.markdown(f"**💬 Final Answer:** {response['result']}")
        
#         except Exception as e:
#             st.error(f"⚠️ Error occurred: {e}")

# # Optional: Show debug logs
# if st.checkbox('Show Debug Log', False):
#     with open('agent.log', 'r') as log_file:
#         st.text_area("Debug Log", log_file.read(), height=300)



# import streamlit as st
# from tools import agent_router

# # Page config
# st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# # Title
# st.title("📚 Multi-Agent RAG Q&A")

# # Layout with search bar and file uploader
# col1, col2 = st.columns([5, 1])

# with col1:
#     query = st.text_input("Ask me anything...")

# with col2:
#     uploaded_files = st.file_uploader("📂", type=["pdf", "docx", "txt"], accept_multiple_files=True, label_visibility="collapsed")

# # Enhanced display of uploaded files
# if uploaded_files:
#     st.markdown("### 📂 Upload documents")
#     st.write("Drag and drop files here")
#     st.caption("Limit 200MB per file • TXT, MD, PDF, DOCX, CSV")

#     for file in uploaded_files:
#         file_size_kb = file.size / 1024
#         st.markdown(f"**📄 {file.name}** — `{file_size_kb:.1f} KB`")

#     st.success("✅ Documents processed and indexed.")

# # Process query if provided
# if query:
#     with st.spinner("Thinking..."):
#         try:
#             response = agent_router(query)

#             st.success("✅ Answer generated!")
#             st.markdown(f"🔁 Agent Path Chosen: **{response['route']}**")

#             if 'context' in response:
#                 st.markdown("**📄 Top Retrieved Chunks:**")
#                 for i, chunk in enumerate(response['context']):
#                     st.markdown(f"**Chunk {i+1}:** {chunk}")

#             st.markdown(f"**💬 Final Answer:** {response['result']}")

#         except Exception as e:
#             st.error(f"⚠️ Error occurred: {e}")

# # Optional: Show debug logs
# if st.checkbox('Show Debug Log', False):
#     with open('agent.log', 'r') as log_file:
#         st.text_area("Debug Log", log_file.read(), height=300)
# import streamlit as st
# from tools import agent_router

# # Page config
# st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# # Title
# st.title("📚 Multi-Agent RAG Q&A")

# # Layout with search bar and file uploader
# col1, col2 = st.columns([5, 1])

# # File uploader
# with col2:
#     uploaded_files = st.file_uploader(
#         "📂", 
#         type=["pdf", "docx", "txt"], 
#         accept_multiple_files=True, 
#         label_visibility="collapsed"
#     )

# # Determine placeholder text dynamically
# placeholder_text = "Ask anything from the uploaded document..." if uploaded_files else "Ask me anything..."

# # Text input with dynamic placeholder
# with col1:
#     query = st.text_input("Ask a question:", placeholder=placeholder_text)

# # Show uploaded files nicely
# if uploaded_files:
#     st.markdown("### 📂 Uploaded Documents")
#     for file in uploaded_files:
#         file_size_kb = file.size / 1024
#         st.markdown(f"**📄 {file.name}** — `{file_size_kb:.1f} KB`")
#     st.success("✅ Documents processed and indexed.")

# # If a query is provided, process it
# if query:
#     with st.spinner("Thinking..."):
#         try:
#             response = agent_router(query)

#             if 'context' in response:
#                 st.markdown("### 🔎 Retrieved Chunks:")
#                 for i, chunk in enumerate(response['context']):
#                     st.markdown(f"**Chunk {i+1}:** {chunk}")

#             st.markdown("### 🤖 Answer:")
#             st.success(response['result'])

#         except Exception as e:
#             st.error(f"⚠️ Error occurred: {e}")

# # Debug log view toggle
# if st.checkbox('Show Debug Log', False):
#     try:
#         with open('agent.log', 'r') as log_file:
#             st.text_area("Debug Log", log_file.read(), height=300)
#     except FileNotFoundError:
#         st.warning("No debug log file found.")

import streamlit as st
from tools import agent_router

# Page config
st.set_page_config(page_title="Multi-Agent RAG Q&A Assistant")

# Title
st.title("📚 Multi-Agent RAG Q&A")

# Layout with search bar and file uploader
col1, col2 = st.columns([5, 1])

# File uploader
with col2:
    uploaded_files = st.file_uploader(
        "📂", 
        type=["pdf", "docx", "txt"], 
        accept_multiple_files=True, 
        label_visibility="collapsed"
    )

# Dynamic placeholder
placeholder_text = "Ask anything from the uploaded document..." if uploaded_files else "Ask me anything..."

# Query input
with col1:
    query = st.text_input("Ask a question:", placeholder=placeholder_text)

# Show uploaded files
if uploaded_files:
    st.markdown("### 📂 Uploaded Documents")
    for file in uploaded_files:
        size_kb = file.size / 1024
        st.markdown(f"**📄 {file.name}** — `{size_kb:.1f} KB`")
    st.success("✅ Documents processed and indexed.")

# Handle query
if query:
    with st.spinner("Thinking..."):
        try:
            response = agent_router(query)

            # Display retrieved chunks
            if 'context' in response:
                st.markdown("### 🔎 Retrieved Chunks:")
                for i, chunk in enumerate(response['context']):
                    if chunk.strip():  # Skip empty chunks
                        st.markdown(f"**Chunk {i+1}:** {chunk}")

            # Final answer
            st.markdown("### 🤖 Answer:")
            st.success(response['result'])

        except Exception as e:
            st.markdown("### 🤖 Answer:")
            st.error(f"{e}")
